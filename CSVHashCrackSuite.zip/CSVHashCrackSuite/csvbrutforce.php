#!/usr/bin/php

<?php
	error_reporting(0);

	// PRESETS FOR CHARSETS
	$_PRESET['num']         = "0123456789";
	$_PRESET['alphaLow']    = "abcdefghijklmnopqrstuvwxyz";
	$_PRESET['alphaNumLow'] = "0123456789abcdefghijklmnopqrstuvwxyz";
	$_PRESET['alphaNumMix'] = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIKLMNOPQRSTUVWXYZ";

	$_VERSION = "1.0.3";

	$inputfile = '';
	$outfile = '';
	$wordlist = '';
	$algorithm = '';
	$delimiter = '';
	$quotechar = '';
	$enclosure = '';
	
	$_hashList = "md2 / md4 / md5 / sha1  / sha256 / sha384 / sha512 / ripemd128 / ripemd160 / ripemd256 / ripemd320 / whirlpool / tiger128,3 / tiger160,3 / tiger192,3 / tiger128,4 / tiger160,4 / tiger192,4 / snefru / gost / adler32 / crc32 / crc32b / haval128,3 / haval160,3 / haval192,3 / haval224,3 / haval256,3 / haval128,4 / haval160,4 / haval192,4 / haval224,4 / haval256,4 / haval128,5 / haval160,5 / haval192,5 / haval224,5 / haval256,5";
	
	$_charsetList = "";
	foreach($_PRESET as $k => $v){
		$_charsetList .= "$k: $v\n";
	}
	
	$_help = "CSVHashBruteforcer by Mark.B
====================== \n
CSVHashBruteforcer is a offline password bruteforce-tool designed to crack CSV-files like dumps from sqlmap in the smallest ammount of time. 
For more inforamtion and benchmaks see: https://sourceforge.net/projects/csvhashcrack/ \n
Usage: 
------
csvbruteforce.php -i <inputfile> -l <length> -s <characterset> -c <column> \n
e.g.: \n
csvbruteforce.php -i input.csv -l 6-8 -s alphaNumLow -c 12 \n
csvbruteforce.php -i input.csv -l 8-8 -s 0123456789abcdef -c 12 \n
Additional options: 
-------------------
-o <outputfile> [default = inputfile.cracked] 
-a <algorithm>  [default = md5] 
-d <delimiter>  [default = ,] 
-e <enclosure>  [default = \"] 
-q <quotechar>  [default = \\] \n
Supported algorithms: 
---------------------
$_hashList\n
Charset-names: 
---------------------
$_charsetList\n";
	
	# ARGV parsing
	$options = getopt("hvi:o:l:s:a:d:e:q:c:",["help", "version", "infile=","outfile=","length=","charset=","algorithm=","delimiter=","enclosure=","quotechar=","column="]);
	
	if(count($options) < 4){	
		if(!isset($options['v']) AND !isset($options['h']))
			die("$_help \n");
	}
	
	foreach($options as $opt => $arg){
		if($opt == 'h')
			die("$_help \n");
		if($opt == 'v')
			die("CSVHashBruteforcer version $_VERSION \n\n");
		elseif($opt == "i")
			$inputfile = trim($arg);
		elseif($opt == "o")
			$outfile = trim($arg);
		elseif($opt == "l")
			$from_to = trim($arg);
		elseif($opt == "s")
			$chars = trim($arg);
		elseif($opt == "a")
			$algorithm = trim($arg);
		elseif($opt == "d")
			$delimiter = trim($arg);
		elseif($opt == "e")
			$quotechar = trim($arg);
		elseif($opt == "q")
			$quotechar = trim($arg);
		elseif($opt == "c")
			$column = $arg - 1;
	}
	
	# Use standard values for options if not set
	$fallback = false;
	
	if($algorithm == ''){
		$algorithm = 'md5';
		$fallback = true;
		echo "INFO: Algorithm not set - using $algorithm \n";
	}
	if($outfile == ''){
		$outfile = $inputfile.'.cracked';
		$fallback = true;
		echo "INFO: Output-file not set - using $outfile \n";
	}
	if($delimiter == ''){
		$delimiter = ',';
		$fallback = true;
		echo "INFO: Delimiter-char not set - using $delimiter \n";
	}
	if($enclosure == ''){
		$enclosure = '"';
		$fallback = true;
		echo "INFO: Enclosure-char not set - using $enclosure \n";
	}
	if($quotechar == ''){
		$quotechar = '\\';
		$fallback = true;
		echo "INFO: Quotechar-char not set - using $quotechar \n";
	}
	
	if($fallback)
		echo "\n";
	
	# Check if valid hash-algorithm
	if(strpos("xxx$_hashList", $algorithm) < 1){
		die("ERROR: Algorithm '$algorithm' is unknown! \n");
	}
	
	# Initialize counters with 0
	$i = 0;
	$j = 0;
	
	$ii = 0;
	$jj = 0;
	
	// USE PRESET IF MATCH
	if($_PRESET[$chars] != "")
		$chars = $_PRESET[$chars];
	
	// SPLIT ARGS FOR LOOPS
	list($FROM, $TO) = explode("-", $from_to);
	$CHARS = str_split($chars);
	
	
	# Open csv-file, read in array and count lines 
	if (($handleCSV = fopen($inputfile, "r")) !== FALSE) {
		echo "LOADING CSV: ";
		while (($data = fgetcsv($handleCSV, 4096, "$delimiter", "$enclosure", "$quotechar")) !== false) {
			$jj++;
			$CSV[$data[$column]][] = $data;
			if($jj == 1){ $headKey = $data[$column]; }
		}
		echo number_format($jj, 0, "", ".")." LINES TOTAL \n\n";
	}
	else{
		die("ERROR: Can't read $inputfile \n");
	}
	fclose($handleCSV);
	
	# The outfile cant be inputfile
	if($outfile == $inputfile) {
		die("ERROR: The output-file can't be the same as the input-file! \n");
	}
	
	# Open outfile for writing if not exist
	if(!file_exists($outfile)){
		if(($handleOUT = fopen($outfile, "w")) === FALSE) {
			die("ERROR: Can't open $outfile for writing \n");
		}
	}
	# Open outfile for appending if exists
	else{
		if(($handleOUT = fopen($outfile, "a")) === FALSE) {
			die("ERROR: Can't open $outfile for writing \n");
		}
		else{
			echo "INFO: $outfile exists - appending new cracked lines \n";
		}
	}
	
	# Write headline to outfile
	foreach($CSV[$headKey] as $dkey => $dval){
		$dval[] = "CRACKED";
		
		# Create headlone for output 
		fputcsv($handleOUT, $dval, "$delimiter", "$enclosure", "$quotechar");
	}
	
	# Remember start-time
	$time = time() - 1;
	echo "\n";
	
	// Calculate max passwords
	for($k = $FROM; $k <= $TO; $k++){
		$j += pow(strlen($chars), $k);
	}
	echo "$j PASSWORDS TO TEST TOTAL \n\n";
	
	// CRACK-FUNCTION
	function crackPW($pw, $algorithm, &$CSV, &$i, &$j, &$ii, &$jj, &$handleOUT, $time, $delimiter, $enclosure, $quotechar){
		// FORMATED TIME-OUTPUT
		if(!function_exists(outputTime)){
			function outputTime($sec){
				$s = $sec % 60;
				$m = (($sec - $s) / 60) % 60;
				$h = (($sec - $s - $m * 60) / 60) / 60 % 24;
				$d = (($sec - $s - $m * 60 - $h * 3600) / 60) / 60 / 24;
				
				if($s < 10) $s = "0$s";
				if($m < 10) $m = "0$m";
				if($h < 10) $h = "0$h";
				
				return("$d d $h h $m m $s s");
			}
		}		
		
		$i++;
		$hash = hash($algorithm, $pw);
		
		# If hash get found
		if(isset($CSV[$hash])){
			$ii += count($CSV[$hash]);
			
			# Calc %-values
			$proz1 = round($i / $j * 100, 4);
			$proz1 = number_format($proz1, 4, ".", "")." %";
			if($proz1 < 10){ $proz1 = " $proz1"; }
			if($proz1 < 100){ $proz1 = " $proz1"; }
			
			$proz2 = round($ii / $jj * 100, 2);
			$proz2 = number_format($proz2, 2, ".", "")." %";
			if($proz2 < 10){ $proz2 = " $proz2"; }
			if($proz2 < 100){ $proz2 = " $proz2"; }
			
			# Calculate remining time
			$sec = ceil(time() - $time);
			$remaining = outputTime(ceil($sec / $i * ($j - $i)));
			
			# Write line(s) to outfile
			foreach($CSV[$hash] as $dkey => $dval){
				$dval[] = $pw;
				
				# Create Line for output 
				fputcsv($handleOUT, $dval, "$delimiter", "$enclosure", "$quotechar");
			}
			
			# Ouptput
			echo "$proz1 TESTED :: $proz2 OF PASSWORDS CRACKED :: $remaining LEFT :: $hash == $pw \n";
			
			# Remove cracked passwords from CSV-array to prevent double-lines in case the wordlist is inperfect 
			unset($CSV[$hash]);
			
			# End when last password cracked
			if($ii == $jj)
				die("\nDONE IN ".outputTime(ceil(time() - $time))."! \n\n");
		}
		/*else{
			//echo "$pw   \r";
		}*/
	
		return 0;
	}
	
	
	// RUN THE CRACKING PROCESS
	for($k = $FROM; $k <= $TO; $k++){
		//echo "CHECKING PW-LENGTH $k \n";
		foreach($CHARS as $k1 => $v1){
			$len = 1;
			
			if($len == $k){
				$pass = "$v1";
				crackPW($pass, $algorithm, $CSV, $i, $j, $ii, $jj, $handleOUT, $time, $delimiter, $enclosure, $quotechar);
				continue;
			}
			
			foreach($CHARS as $k2 => $v2){
				$len = 2;
				if($len == $k){
					$pass = "$v1$v2";
					crackPW($pass, $algorithm, $CSV, $i, $j, $ii, $jj, $handleOUT, $time, $delimiter, $enclosure, $quotechar);
					continue;
				}
				
				foreach($CHARS as $k3 => $v3){
					$len = 3;
					if($len == $k){
						$pass = "$v1$v2$v3";
						crackPW($pass, $algorithm, $CSV, $i, $j, $ii, $jj, $handleOUT, $time, $delimiter, $enclosure, $quotechar);
						continue;
					}
					
					foreach($CHARS as $k4 => $v4){
						$len = 4;
						if($len == $k){
							$pass = "$v1$v2$v3$v4";
							crackPW($pass, $algorithm, $CSV, $i, $j, $ii, $jj, $handleOUT, $time, $delimiter, $enclosure, $quotechar);
							continue;
						}
												
						foreach($CHARS as $k5 => $v5){
							$len = 5;
							if($len == $k){
								$pass = "$v1$v2$v3$v4$v5";
								crackPW($pass, $algorithm, $CSV, $i, $j, $ii, $jj, $handleOUT, $time, $delimiter, $enclosure, $quotechar);
								continue;
							}
							
							foreach($CHARS as $k6 => $v6){
								$len = 6;
								if($len == $k){
									$pass = "$v1$v2$v3$v4$v5$v6";
									crackPW($pass, $algorithm, $CSV, $i, $j, $ii, $jj, $handleOUT, $time, $delimiter, $enclosure, $quotechar);
									continue;
								}
																
								foreach($CHARS as $k7 => $v7){
									$len = 7;
									if($len == $k){
										$pass = "$v1$v2$v3$v4$v5$v6$v7";
										crackPW($pass, $algorithm, $CSV, $i, $j, $ii, $jj, $handleOUT, $time, $delimiter, $enclosure, $quotechar);
										continue;
									}
									
									foreach($CHARS as $k8 => $v8){
										$len = 8;
										if($len == $k){
											$pass = "$v1$v2$v3$v4$v5$v6$v7$v8";
											crackPW($pass, $algorithm, $CSV, $i, $j, $ii, $jj, $handleOUT, $time, $delimiter, $enclosure, $quotechar);
											continue;
										}
										
										foreach($CHARS as $k9 => $v9){
											$len = 9;
											if($len == $k){
												$pass = "$v1$v2$v3$v4$v5$v6$v7$v8$v9";
												crackPW($pass, $algorithm, $CSV, $i, $j, $ii, $jj, $handleOUT, $time, $delimiter, $enclosure, $quotechar);
												continue;
											}
											
											// MAX-LENGTH LIMITED TO 10 FOR TIME REASON
											foreach($CHARS as $k10 => $v10){
												crackPW($pass, $algorithm, $CSV, $i, $j, $ii, $jj, $handleOUT, $time, $delimiter, $enclosure, $quotechar);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	fclose($handleWL);
	fclose($handleOUT);

	echo "\nDONE IN ".outputTime(ceil(time() - $time))."! \n\n";
?>
